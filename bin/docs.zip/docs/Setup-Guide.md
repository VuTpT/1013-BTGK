# HƯỚNG DẪN CÀI ĐẶT & CHẠY – STEP BY STEP

> Mỗi bước có ô **✅ Kiểm chứng** — chụp màn hình kết quả của lệnh kiểm chứng và lưu vào `docs/images/`
> theo thứ tự `01-jdk.png`, `02-maven.png`, … để dựng video.
>
> Toàn bộ phần **bắt buộc** (mục 1–4) chạy được **offline** sau lần tải thư viện đầu tiên.

---

## 0. Yêu cầu tối thiểu

| Thành phần | Bắt buộc? | Dùng cho |
| --- | --- | --- |
| JDK 17, Maven 3.9+ | ✅ Bắt buộc | Toàn bộ dự án |
| Google Chrome | ✅ Bắt buộc | Selenium, Playwright |
| Git + tài khoản GitHub | ✅ Bắt buộc | Quản lý mã nguồn, CI |
| Tài khoản Jira Cloud (free) | ✅ Bắt buộc | Quản lý test case |
| Allure CLI | Khuyến nghị | Xem báo cáo cục bộ |
| Jenkins | Khuyến nghị | Dây chuyền CI chính |
| Selenium Grid | Tùy chọn | Chạy đa trình duyệt |
| Node.js, Android Studio, Appium | Tùy chọn | Tầng mobile |

---

## 1. Nền tảng Java

### Bước 1 — JDK 17

Tải Temurin 17 (hoặc Oracle JDK 17), cài đặt, đặt biến môi trường `JAVA_HOME`.

```bash
java -version
```

✅ **Kiểm chứng**: `openjdk version "17.0.x"` (dự án đã kiểm thử trên `17.0.12`).

### Bước 2 — Maven 3.9.16

Bản Maven đã có sẵn trong kho bài tập: `1013\apache-maven-3.9.16`. Thêm thư mục `bin` vào `PATH`:

```powershell
# PowerShell - thêm vĩnh viễn cho người dùng hiện tại
$maven = "D:\DHHS\HK7\Code\1013\apache-maven-3.9.16\bin"
[Environment]::SetEnvironmentVariable("PATH", "$env:PATH;$maven", "User")
```

Mở **cửa sổ terminal mới** rồi kiểm tra:

```bash
mvn -v
```

✅ **Kiểm chứng**: `Apache Maven 3.9.16` và dòng `Java version: 17.x`.

### Bước 3 — Mở dự án bằng NetBeans (hoặc IntelliJ)

`File > Open Project` → chọn thư mục `BTCK/automation` (dự án Maven đa module).

✅ **Kiểm chứng**: cây dự án hiển thị đủ **7 module**: `sut-core`, `unit-tests`, `coverage-report`,
`test-support`, `web-selenium`, `web-playwright`, `mobile-appium`.

---

## 2. Chạy tầng UNIT (JUnit 5 + EasyMock + JaCoCo)

```bash
cd BTCK/automation
mvn clean verify
```

Lần đầu Maven tải thư viện (~2–3 phút, cần Internet); các lần sau chạy offline được.

✅ **Kiểm chứng**:

```
Tests run: 144, Failures: 0, Errors: 0, Skipped: 0
BUILD SUCCESS
```

Xem báo cáo độ phủ:

```
coverage-report/target/site/jacoco-aggregate/index.html
```

✅ **Kiểm chứng**: độ phủ lệnh ≈ **91%**, độ phủ nhánh ≈ **89%**.

---

## 3. Chạy tầng WEB UI (Selenium 4 + TestNG)

### Bước 4 — Kiểm tra Chrome

Chỉ cần cài Chrome; **không cần tải ChromeDriver thủ công** — từ Selenium 4.6 trở đi,
**Selenium Manager** tự tải driver đúng phiên bản (khác với bài W12 phải gọi
`System.setProperty("webdriver.chrome.driver", …)`).

### Bước 5 — Chạy toàn bộ suite

```bash
mvn test -Pui -pl web-selenium
```

✅ **Kiểm chứng**:

```
[SUT] MiniShop dang chay tai http://127.0.0.1:<cổng ngẫu nhiên>/index.html
Tests run: 36, Failures: 0, Errors: 0, Skipped: 0
```

> SUT được phục vụ bởi `LocalWebServer` (lớp dùng `com.sun.net.httpserver` có sẵn trong JDK) —
> không cần cài web server, không cần Internet.

### Bước 6 — Các biến thể khi chạy

```bash
# Xem trình duyệt chạy thật (quay video):
mvn test -Pui -pl web-selenium -Dheadless=false

# Chỉ chạy nhóm smoke (6 test case, ~7 giây):
mvn test -Pui -pl web-selenium -DsuiteXmlFile=src/test/resources/testng-smoke.xml

# Đổi trình duyệt:
mvn test -Pui -pl web-selenium -Dbrowser=firefox
mvn test -Pui -pl web-selenium -Dbrowser=edge

# Gỡ lỗi tuần tự một lớp:
mvn test -Pui -pl web-selenium -DsuiteXmlFile=src/test/resources/testng-debug.xml
```

### Bước 7 — Selenium Grid (tùy chọn)

Tải `selenium-server-4.21.0.jar` từ trang chủ Selenium, rồi:

```bash
java -jar selenium-server-4.21.0.jar standalone
# Mở http://localhost:4444/ui để xem các node
mvn test -Pui -pl web-selenium -Dgrid.url=http://localhost:4444
```

✅ **Kiểm chứng**: giao diện Grid hiển thị các phiên đang chạy trong lúc test thực thi.

### Bước 8 — Selenium IDE (tùy chọn, để quay phần record & playback)

Cài tiện ích **Selenium IDE** trên Chrome/Firefox → Record kịch bản đăng nhập trên MiniShop →
Play lại → `Export` sang **Java JUnit** → so sánh với mã Page Object viết tay.
Lưu tập tin `.side` vào thư mục `selenium-ide/`.

---

## 4. Chạy tầng đối chứng Playwright

```bash
mvn test -Pui -pl web-playwright
```

Mặc định dùng **Chrome đã cài trên máy** (`-Dpw.channel=chrome`) nên **không phải tải Chromium riêng**.
Nếu muốn dùng bộ trình duyệt riêng của Playwright (chromium/firefox/webkit):

```bash
mvn exec:java -pl web-playwright -D exec.mainClass=com.microsoft.playwright.CLI -D exec.args="install"
mvn test -Pui -pl web-playwright -Dpw.channel=
```

✅ **Kiểm chứng**: `Tests run: 5, Failures: 0`.

Xem lại từng bước của một test bằng **Trace Viewer**:

```bash
npx playwright show-trace web-playwright/target/traces/tcPw005_placeOrder.zip
```

---

## 5. Báo cáo Allure

### Bước 9 — Cài Allure CLI

```powershell
# Cách 1: scoop
scoop install allure
# Cách 2: npm
npm install -g allure-commandline
allure --version
```

### Bước 10 — Xem báo cáo

```bash
# Tầng unit
allure serve unit-tests/target/allure-results

# Gộp cả 4 tầng vào một báo cáo duy nhất
allure generate unit-tests/target/allure-results web-selenium/target/allure-results ^
                web-playwright/target/allure-results --clean -o target/allure-report
allure open target/allure-report
```

✅ **Kiểm chứng**: báo cáo hiển thị đủ các Epic *Tầng 1 – Unit test*, *Tầng 2 – Web UI*,
*Tầng 2b – Playwright*; bấm vào một test case có gắn `@Issue` sẽ mở thẳng issue trên Jira
(sửa `<ten-site>` trong `src/test/resources/allure.properties` thành tên site Jira của nhóm).

---

## 6. Jira

### Bước 11 — Tạo project và nhập test case

1. Tạo site Jira Cloud miễn phí → tạo project **KTPM** (template **Scrum**).
2. Bật issue type **Test** (Project settings → Issue types → thêm từ mẫu Task).
3. `Settings → System → External System Import → CSV` → tải lên [jira-import.csv](jira-import.csv).
4. Ánh xạ cột: `Issue Type`, `Summary`, `Description`, `Priority`, `Labels`, `Epic Link`, `Assignee`, `Status`.

✅ **Kiểm chứng**: board có 5 Epic, 24 issue **Test**, 3 **Task**, 1 **Bug**.

### Bước 12 — Nối Jira với GitHub

Cài app **GitHub for Jira** (miễn phí trên Atlassian Marketplace) → kết nối tổ chức GitHub →
từ đó mọi nhánh/commit/PR có chứa mã issue (`KTPM-105`) sẽ hiện trong mục *Development* của issue.

---

## 7. Jenkins

### Bước 13 — Cài và khởi động

```bash
java -jar jenkins.war --httpPort=8080
```

Mở `http://localhost:8080`, nhập mã unlock, cài các plugin: **Git, Pipeline, Maven Integration,
JUnit, Allure Jenkins Plugin, HTML Publisher**.

### Bước 14 — Khai báo Tools

`Manage Jenkins → Tools`: thêm **JDK** tên `jdk17`, **Maven** tên `maven3`, **Allure Commandline** tên `allure`
(đúng các tên này vì `ci/Jenkinsfile` tham chiếu tới chúng).

### Bước 15 — Tạo Pipeline job

`New Item → Pipeline` → *Pipeline script from SCM* → Git → URL repo → *Script Path*: `BTCK/ci/Jenkinsfile`.
Bật **Poll SCM** (`H/5 * * * *`) hoặc webhook.

✅ **Kiểm chứng**: build chạy qua đủ các stage *Build → Tầng 1 → Tầng 2 → Tầng 2b* và xuất hiện
liên kết **Allure Report** ở trang kết quả build.

---

## 8. GitHub Actions

### Bước 16 — Kích hoạt

Chép `BTCK/ci/workflows/ci.yml` sang `<gốc repo>/.github/workflows/ci.yml`, commit và push.

✅ **Kiểm chứng**: tab **Actions** trên GitHub hiện 2 job *Tầng 1 – Unit test* và *Tầng 2 – Smoke UI*
chạy xanh; thêm badge vào `README.md`.

---

## 9. Tầng mobile (tùy chọn)

### Bước 17 — Cài Appium

```bash
npm install -g appium
appium driver install uiautomator2
npm install -g appium-doctor && appium-doctor --android
```

### Bước 18 — Chạy

1. Mở Android Emulator (API 30+, có sẵn Chrome).
2. Khởi động server: `appium`
3. Chạy test:

```bash
mvn test -Pmobile -pl mobile-appium -Dskip.mobile.tests=false
```

✅ **Kiểm chứng**: `Tests run: 3, Failures: 0`. Dùng **Appium Inspector** để chụp màn hình cây phần tử.

> Emulator truy cập máy thật qua địa chỉ `10.0.2.2` (đã xử lý sẵn trong `MiniShopMobileTest`).

---

## 10. Sự cố thường gặp

| Hiện tượng | Nguyên nhân | Cách xử lý |
| --- | --- | --- |
| `mvn` không nhận lệnh | Chưa thêm vào `PATH` | Làm lại Bước 2, mở terminal mới |
| `Could not find artifact vn.edu.ktpm:minishop-automation:pom` | Chạy `-pl <module>` khi chưa cài pom cha | Chạy `mvn -N install` một lần, hoặc thêm `-am` |
| `TimeoutException` khi khởi tạo ChromeDriver | Chạy song song quá nhiều trình duyệt | Giữ `parallel="classes" thread-count="2"` trong `testng.xml` |
| `Khong tim thay thu muc sut-web` | Chạy Maven từ thư mục lạ | Chạy từ `BTCK/automation`, hoặc thêm `-Dsut.web.dir=<đường dẫn>` |
| Playwright báo thiếu trình duyệt | Chưa có Chrome hoặc đã xóa `pw.channel` | Đặt lại `-Dpw.channel=chrome`, hoặc chạy `playwright install` |
| Test mobile bị bỏ qua | `skip.mobile.tests` mặc định `true` | Thêm `-Dskip.mobile.tests=false` |
