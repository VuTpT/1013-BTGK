# DANH SÁCH TEST CASE – MiniShop

> Nguồn gốc từng test case (kỹ thuật thiết kế nào sinh ra nó) xem [TestDesign-Techniques.md](TestDesign-Techniques.md).
> Ánh xạ ngược về yêu cầu và mã Jira xem [TraceabilityMatrix.md](TraceabilityMatrix.md).
>
> **Tổng cộng: 185 test case** — 144 unit (JUnit 5) · 36 UI (Selenium + TestNG) · 5 đối chứng (Playwright) · 3 mobile (Appium, tùy chọn).
> Ký hiệu `[n]` là số biến thể dữ liệu của một test method tham số hóa.

---

## 1. Tầng UNIT – JUnit 5 (`automation/unit-tests`)

### 1.1 FR-06 Calculator — `CalculatorTest` (17 TC)

| ID | Tiêu đề | Kỹ thuật | Dữ liệu | Kỳ vọng |
| --- | --- | --- | --- | --- |
| TC-UNIT-001 [4] | `add()` trả về tổng | EP | (2,3) (−2,3) (0,0) (2.5,2.5) | 5, 1, 0, 5.0 |
| TC-UNIT-002 | `add()` **notEquals** giá trị sai | Kiểm chứng âm | (2,3) | ≠ 6.0 |
| TC-UNIT-003 [3] | `sub()` trả về hiệu | EP | (5,3) (3,5) (0,0) | 2, −2, 0 |
| TC-UNIT-004 | `sub()` **notEquals** giá trị sai | Kiểm chứng âm | (5,3) | ≠ 3.0 |
| TC-UNIT-005 [3] | `mul()` trả về tích | EP | (4,3) (−4,3) (0,99) | 12, −12, 0 |
| TC-UNIT-006 [3] | `div()` trả về thương | EP | (6,3) (−6,3) (1,4) | 2, −2, 0.25 |
| TC-UNIT-007 | `div()` chia cho 0 | Lớp không hợp lệ | (6,0) | Ném `ArithmeticException` |
| TC-UNIT-008 | Bốn phép tính trên cùng bộ dữ liệu (`assertAll`) | Gộp | (10,4) | 14, 6, 40, 2.5 |

### 1.2 FR-06 Rational — `RationalTest` (36 TC)

| ID | Tiêu đề | Kỹ thuật | Kỳ vọng |
| --- | --- | --- | --- |
| TC-UNIT-010 | Constructor mặc định | Hộp trắng | `0/1` |
| TC-UNIT-011 [6] | Chuẩn hóa: rút gọn, mẫu dương | Hộp trắng (`normalize`, `GCD`) | 2/4→1/2 · 3/9→1/3 · −1/−2→1/2 · 1/−2→−1/2 · 0/5→0/1 · 7/1→7/1 |
| TC-UNIT-012 | Mẫu số = 0 | Giá trị biên không hợp lệ | Ném `Illegal` |
| TC-UNIT-013 [4] | `add()` | EP | 1/2+1/3=5/6 … |
| TC-UNIT-014 [3] | `subtract()` | EP | 1/2−1/3=1/6 … |
| TC-UNIT-015 [3] | `multiply()` | EP | 2/3×3/4=1/2 … |
| TC-UNIT-016 [3] | `divide()` — phủ đường đi bình thường | **Phủ nhánh** | 1/2 ÷ 1/3 = 3/2 … |
| TC-UNIT-017 | `divide()` cho phân số 0 | **Phủ nhánh** | Ném `Illegal`, trạng thái **không đổi** |
| TC-UNIT-018 | `equals()` hai cách viết cùng giá trị | Kiểm chứng dương | 1/2 = 2/4 |
| TC-UNIT-019 | `notEquals` khác giá trị / khác kiểu | Kiểm chứng âm | 1/2 ≠ 1/3, ≠ "1/2" |
| TC-UNIT-020 [3] | `compareTo()` trả về đúng dấu | EP | +1, −1, 0 |
| TC-UNIT-021 | `compareTo()` với kiểu khác | Lớp không hợp lệ | `IllegalArgumentException` |
| TC-UNIT-022 [4] | `toString()` | EP | `1/2`, `2`, `0`, `-1/2` |
| TC-UNIT-023 [4] | Mẫu số dương bất kỳ | Biên trên | 1, 2, 100, `Integer.MAX_VALUE` |

### 1.3 FR-01 Đăng nhập — `LoginServiceTest` (14 TC, dùng EasyMock)

| ID | Trạng thái → sự kiện → trạng thái | Kỹ thuật | Kỳ vọng |
| --- | --- | --- | --- |
| TC-UNIT-030 | ChưaĐN → nhập đúng → ĐãĐN | Sơ đồ trạng thái S1 | `SUCCESS` |
| TC-UNIT-031 [2] | ChưaĐN → sai lần 1, 2 → ChưaĐN | S2, S3 | `INVALID_CREDENTIAL`, còn 2 / còn 1 lượt |
| TC-UNIT-032 | ChưaĐN → sai lần 3 → KhóaTạm | S4 | `LOCKED`, `lockedUntil` = now + 15′ |
| TC-UNIT-033 | KhóaTạm → nhập **đúng** → KhóaTạm | S5 | `LOCKED`, còn 15 phút |
| TC-UNIT-034 | KhóaTạm ở giây thứ 899 | **Biên thời gian** | Vẫn `LOCKED`, còn 1 phút |
| TC-UNIT-035 | KhóaTạm → hết 15′ → ĐãĐN | S7 | `SUCCESS`, bộ đếm reset 0 |
| TC-UNIT-036 [4] | Bỏ trống ô nhập | S8 | `EMPTY_INPUT`, **không gọi repository** |
| TC-UNIT-037 | Tài khoản không tồn tại | S9 | `INVALID_CREDENTIAL` (không lộ thông tin) |
| TC-UNIT-038 | Tài khoản bị vô hiệu hóa | S10 | `DISABLED` |
| TC-UNIT-039 | Đăng nhập đúng sau 2 lần sai | S1 | `SUCCESS`, bộ đếm về 0 |

> Cả 14 test case đều **mock `UserRepository` bằng EasyMock** và **tua thời gian bằng `MutableClock`** —
> minh họa trực tiếp yêu cầu của bài W10.

### 1.4 FR-02 Giỏ hàng — `CartTest` (16 TC)

| ID | Tiêu đề | Kỹ thuật | Kỳ vọng |
| --- | --- | --- | --- |
| TC-UNIT-040 [4] | Số lượng 1, 2, 9, 10 | **BVA hợp lệ** | Chấp nhận |
| TC-UNIT-041 [4] | Số lượng −1, 0, 11, 100 | **BVA không hợp lệ** | `CartException`, giỏ **không đổi** |
| TC-UNIT-042 | Thêm lại sản phẩm đã có | EP | Cộng dồn 3+4=7 |
| TC-UNIT-043 | Cộng dồn đúng 10 | **BVA** | Chấp nhận |
| TC-UNIT-044 | Cộng dồn vượt 10 | **BVA** | Từ chối, giữ số lượng cũ |
| TC-UNIT-045 | Đủ 5 loại sản phẩm | **BVA** | Chấp nhận |
| TC-UNIT-046 | Loại sản phẩm thứ 6 | **BVA** | Từ chối |
| TC-UNIT-047 | `subtotal()` | Tính toán | 150k×2 + 120k = 420.000 |
| TC-UNIT-048 | `remove()` sản phẩm có / không có | EP | Xóa được / `CartException` |
| TC-UNIT-049 | `clear()` | EP | Giỏ rỗng, tạm tính 0 |

### 1.5 FR-03 Khuyến mãi — `DiscountPolicyTest` (27 TC)

| ID | Tiêu đề | Kỹ thuật | Kỳ vọng |
| --- | --- | --- | --- |
| TC-UNIT-050 [8] | **Phủ đủ 8 rule của bảng quyết định** | Bảng quyết định | 25, 15, 20, 10, 15, 5, 10, 0 (%) |
| TC-UNIT-051 [3] | Ngưỡng 499.999 / 500.000 / 500.001 | **BVA** | 0% / 5% / 5% |
| TC-UNIT-052 [4] | Mã `SALE10`, `sale10`, `  SALE10  `, `Sale10` | EP hợp lệ | Đều hợp lệ |
| TC-UNIT-053 [5] | Mã `SALE`, `SALE11`, `SALE 10`, rỗng, khoảng trắng | EP không hợp lệ | Không hợp lệ, giảm 0% |
| TC-UNIT-054 | Mã `null` | Lớp biên | Không ném ngoại lệ |
| TC-UNIT-055 [4] | `finalAmount()` làm tròn xuống | Tính toán | 100.001 giảm 10% → 90.001 |
| TC-UNIT-056 | Tạm tính âm | Lớp không hợp lệ | `IllegalArgumentException` |
| TC-UNIT-057 | Tạm tính 0 | Biên dưới | Thành tiền 0 |

### 1.6 FR-04 Thông tin giao hàng — `CheckoutValidatorTest` (30 TC)

| ID | Tiêu đề | Kỹ thuật | Kỳ vọng |
| --- | --- | --- | --- |
| TC-UNIT-060 | Toàn bộ hợp lệ | EP hợp lệ | Không lỗi |
| TC-UNIT-061 [4] | Họ tên 1, 2, 49, 50 ký tự | **BVA hợp lệ** | Không lỗi |
| TC-UNIT-062 [2] | Họ tên 51, 60 ký tự | **BVA không hợp lệ** | Lỗi `fullName` |
| TC-UNIT-063 [6] | Họ tên rỗng / khoảng trắng / có số / ký tự lạ | EP không hợp lệ | Lỗi `fullName` |
| TC-UNIT-064 | Họ tên tiếng Việt có dấu | EP hợp lệ | Không lỗi |
| TC-UNIT-065 [3] | SĐT `0912345678`, `0000000000`, `0987654321` | EP hợp lệ | Không lỗi |
| TC-UNIT-066 [7] | SĐT rỗng, 9 số, 11 số, không bắt đầu 0, có chữ, có khoảng trắng | **BVA + EP** | Lỗi `phone` |
| TC-UNIT-067 [3] | Địa chỉ 1, 99, 100 ký tự | **BVA hợp lệ** | Không lỗi |
| TC-UNIT-068 | Địa chỉ 101 ký tự | **BVA** | Lỗi `address` |
| TC-UNIT-069 | Giỏ hàng rỗng | EP | Lỗi `cart` |
| TC-UNIT-070 | Bốn trường sai cùng lúc | Gộp | Báo đủ 4 lỗi |

### 1.7 FR-04 Đặt hàng — `CheckoutServiceTest` (4 TC, mức tích hợp)

| ID | Tiêu đề | Kỳ vọng |
| --- | --- | --- |
| TC-UNIT-075 | Đặt hàng thành công | Mã đơn `MS…`, giảm 5%, giỏ được xóa |
| TC-UNIT-076 | VIP + `sale10` + đơn 1.000.000 | Tổng 750.000 (giảm 25%) |
| TC-UNIT-077 | Thông tin sai | `CartException`, **giỏ hàng không bị xóa** |
| TC-UNIT-078 | Giỏ hàng rỗng | `CartException` |

---

## 2. Tầng WEB UI – Selenium 4 + TestNG (`automation/web-selenium`)

Tiền điều kiện chung: SUT chạy tại địa chỉ do `LocalWebServer` cấp; mỗi test case bắt đầu bằng
trình duyệt sạch (`localStorage.clear()`).

### 2.1 FR-01 Đăng nhập — `LoginTest` (11 TC)

| ID | Nhóm | Các bước | Dữ liệu | Kỳ vọng |
| --- | --- | --- | --- | --- |
| TC-WEB-001 | smoke | Nhập tài khoản → Đăng nhập | `standard_user` / `secret_sauce` | Vào trang sản phẩm, hiện tên user, giỏ = 0 |
| TC-WEB-002 [6] | regression | Nhập sai → Đăng nhập (**data-driven từ `login-data.csv`**) | user sai · mật khẩu sai · bỏ trống user · bỏ trống mật khẩu · bỏ trống cả hai · `locked_user` | Hiện đúng thông báo lỗi, ở lại trang đăng nhập |
| TC-WEB-003 | regression | Bỏ trống 3 lần rồi nhập đúng | — | Vẫn đăng nhập được (bỏ trống **không** tính vào 3 lần sai) |
| TC-WEB-004 | regression | Đăng nhập tài khoản bị khóa | `locked_user` | "Tài khoản đã bị khóa bởi quản trị viên" |
| TC-WEB-005 | regression | Sai 3 lần liên tiếp, rồi nhập đúng | `standard_user` + 3 mật khẩu sai | Lần 1: "còn 2 lần"; lần 2: "còn 1 lần"; lần 3: khóa; nhập đúng vẫn bị từ chối |
| TC-WEB-006 | smoke | Đăng nhập → Đăng xuất | — | Quay về trang đăng nhập |

### 2.2 FR-02 + FR-03 Giỏ hàng và khuyến mãi — `CartTest` (12 TC)

| ID | Nhóm | Các bước | Dữ liệu | Kỳ vọng |
| --- | --- | --- | --- | --- |
| TC-WEB-010 | smoke | Thêm P01 số lượng 2 → mở giỏ | P01 × 2 | Badge = 2, thành tiền dòng = 300.000 |
| TC-WEB-011 [3] | regression | Thêm với số lượng ngoài miền | 0, 11, 99 | Báo lỗi "Số lượng…", badge vẫn 0 |
| TC-WEB-012 | regression | Thêm số lượng biên hợp lệ | P01 × 1, P02 × 10 | Không báo lỗi, badge = 11 |
| TC-WEB-013 | regression | Thêm 5 loại rồi thêm loại thứ 6 | P01…P06 | 5 loại OK; loại 6 bị từ chối, badge = 5 |
| TC-WEB-014 | regression | Xóa 1 sản phẩm khỏi giỏ | P01, P02 | P01 biến mất, tạm tính = 350.000 |
| TC-WEB-015 | regression | Xóa toàn bộ giỏ | P01 × 3 | Hiện "Giỏ hàng đang trống", tạm tính 0 |
| TC-WEB-016 | smoke | Kiểm tra tạm tính | P01×2 + P05×1 | 420.000 |
| TC-WEB-017 | regression | **Rule R6** của bảng quyết định | Khách thường, P03 (500.000) | Giảm 5%, tổng 475.000 |
| TC-WEB-018 | regression | **Rule R1** của bảng quyết định | VIP, P03×2, mã `sale10` | Giảm 25%, tổng 750.000 |
| TC-WEB-019 | regression | Mã giảm giá sai | `SALE99` | Báo "Mã giảm giá không hợp lệ", giảm 0% |

### 2.3 FR-04 Thanh toán — `CheckoutTest` (12 TC)

| ID | Nhóm | Các bước | Dữ liệu | Kỳ vọng |
| --- | --- | --- | --- | --- |
| TC-WEB-020 | smoke | Điền thông tin hợp lệ → Đặt hàng | `Nguyen Van A` / `0912345678` / địa chỉ hợp lệ | Màn hình thành công, mã `MS…`, tổng 300.000, giỏ được xóa |
| TC-WEB-021 [9] | regression | Điền thông tin không hợp lệ → Đặt hàng | a: họ tên rỗng · b: 51 ký tự · c: có chữ số · d: SĐT rỗng · e: 9 số · f: 11 số · g: không bắt đầu 0 · h: địa chỉ rỗng · i: 101 ký tự | Báo lỗi **đúng trường**, ở lại trang thanh toán |
| TC-WEB-022 | regression | Giá trị biên hợp lệ | Họ tên 50 ký tự, địa chỉ 100 ký tự | Không lỗi, đặt hàng thành công |
| TC-WEB-023 | regression | Thanh toán khi giỏ rỗng | — | Báo "Giỏ hàng đang trống" |

### 2.4 Luồng đầu-cuối — `E2ETest` (1 TC)

| ID | Nhóm | Các bước | Kỳ vọng |
| --- | --- | --- | --- |
| TC-WEB-030 | smoke | VIP đăng nhập → thêm P03 + P02 (850.000) → áp `SALE10` → thanh toán | Giảm 25%, tổng 637.500, đặt hàng thành công, giỏ được xóa |

---

## 3. Tầng đối chứng – Playwright (`automation/web-playwright`)

Năm test case dưới đây **lặp lại chính xác** kịch bản Selenium tương ứng, cùng SUT và cùng dữ liệu;
mục đích là so sánh công cụ chứ không phải tăng độ phủ.

| ID | Tương ứng | Nội dung |
| --- | --- | --- |
| TC-PW-001 | TC-WEB-001 | Đăng nhập hợp lệ |
| TC-PW-002 | TC-WEB-005 | Sai 3 lần → khóa tài khoản |
| TC-PW-003 | TC-WEB-010 | Thêm sản phẩm vào giỏ |
| TC-PW-004 | TC-WEB-018 | VIP + đơn ≥ 500k + `SALE10` → giảm 25% |
| TC-PW-005 | TC-WEB-020 | Đặt hàng thành công (dùng `getByRole`) |

---

## 4. Tầng mobile – Appium (`automation/mobile-appium`, tùy chọn)

| ID | Nội dung | Kỳ vọng |
| --- | --- | --- |
| TC-MOB-001 | Đăng nhập trên Chrome của Android Emulator | Hiện trang sản phẩm |
| TC-MOB-002 | Thêm sản phẩm vào giỏ | Badge = 1 |
| TC-MOB-003 | Đặt hàng | Hiện màn hình thành công |

> Chạy: bật Emulator + `appium`, rồi `mvn test -Pmobile -Dskip.mobile.tests=false`.
> Emulator truy cập máy thật qua địa chỉ `10.0.2.2` thay cho `127.0.0.1`.
