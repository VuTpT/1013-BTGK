# MA TRẬN TRUY VẾT (REQUIREMENTS TRACEABILITY MATRIX)

> Mục đích: chứng minh **mọi yêu cầu đều được kiểm thử** và **mọi test case đều phục vụ một yêu cầu**
> (không có test thừa, không có yêu cầu bỏ sót) — tiêu chí AC-01 và EX-5 trong [TestPlan.md](TestPlan.md).
>
> Mã Jira dưới đây khớp với tập tin [jira-import.csv](jira-import.csv) để nhập hàng loạt vào Jira.

## 1. Ma trận chính: Yêu cầu → Test case → Mã nguồn

| Yêu cầu | Nội dung | Kỹ thuật thiết kế | Test case tầng UNIT | Test case tầng UI | Jira Epic / Issue | Tập tin test | Kết quả |
| --- | --- | --- | --- | --- | --- | --- | --- |
| **FR-01.1** | Đăng nhập đúng → vào hệ thống | Sơ đồ trạng thái S1 | TC-UNIT-030, 039 | TC-WEB-001, TC-PW-001, TC-MOB-001 | KTPM-101 | `LoginServiceTest`, `LoginTest` | ✅ Pass |
| **FR-01.2** | Sai < 3 lần → cho nhập lại | Sơ đồ trạng thái S2, S3 | TC-UNIT-031 | TC-WEB-005 | KTPM-102 | nt | ✅ Pass |
| **FR-01.3** | Sai đủ 3 lần → khóa tạm | Sơ đồ trạng thái S4 | TC-UNIT-032 | TC-WEB-005, TC-PW-002 | KTPM-103 | nt | ✅ Pass |
| **FR-01.4** | Hết thời gian khóa → tự mở, reset bộ đếm | Sơ đồ trạng thái S6, S7 + biên thời gian | TC-UNIT-034, 035 | — (chỉ test ở tầng unit) | KTPM-104 | `LoginServiceTest` | ✅ Pass |
| **FR-01.5** | Đang khóa, nhập đúng vẫn bị từ chối | Sơ đồ trạng thái S5 | TC-UNIT-033 | TC-WEB-005 | KTPM-105 | nt | ✅ Pass |
| **FR-01.6** | Bỏ trống ô nhập → không tính vào 3 lần sai | Sơ đồ trạng thái S8 | TC-UNIT-036 | TC-WEB-003 | KTPM-106 | nt | ✅ Pass |
| **FR-01.7** | Tài khoản bị quản trị viên khóa | Sơ đồ trạng thái S10 | TC-UNIT-038 | TC-WEB-004, TC-WEB-002 | KTPM-107 | nt | ✅ Pass |
| **FR-02.1** | Số lượng mỗi sản phẩm 1..10 | **BVA** | TC-UNIT-040, 041, 043, 044 | TC-WEB-011, 012 | KTPM-110 | `CartTest` (cả 2 tầng) | ✅ Pass |
| **FR-02.2** | Tối đa 5 loại sản phẩm | **BVA** | TC-UNIT-045, 046 | TC-WEB-013 | KTPM-111 | nt | ✅ Pass |
| **FR-02.3** | Thêm sản phẩm đã có → cộng dồn | EP | TC-UNIT-042 | TC-WEB-010, TC-PW-003 | KTPM-112 | nt | ✅ Pass |
| **FR-02.4** | Xóa 1 sản phẩm / xóa toàn bộ giỏ | EP | TC-UNIT-048, 049 | TC-WEB-014, 015 | KTPM-113 | nt | ✅ Pass |
| **FR-02.5** | Tạm tính = Σ(giá × số lượng) | Tính toán | TC-UNIT-047 | TC-WEB-016 | KTPM-114 | nt | ✅ Pass |
| **FR-03.1** | 8 rule khuyến mãi | **Bảng quyết định** | TC-UNIT-050 (8 rule) | TC-WEB-017 (R6), TC-WEB-018 (R1), TC-PW-004 | KTPM-120 | `DiscountPolicyTest` | ✅ Pass |
| **FR-03.2** | Ngưỡng 500.000 tính là ≥ | **BVA** | TC-UNIT-051 | TC-WEB-017 | KTPM-121 | nt | ✅ Pass |
| **FR-03.3** | Mã giảm giá không phân biệt hoa thường, cắt khoảng trắng | EP | TC-UNIT-052, 053, 054 | TC-WEB-018, 019 | KTPM-122 | nt | ✅ Pass |
| **FR-03.4** | Tổng thanh toán làm tròn xuống | Tính toán | TC-UNIT-055, 056, 057 | TC-WEB-018 | KTPM-123 | nt | ✅ Pass |
| **FR-04.1** | Họ tên 1–50 ký tự, chỉ chữ và khoảng trắng | **EP + BVA** | TC-UNIT-061..064 | TC-WEB-021a/b/c, 022 | KTPM-130 | `CheckoutValidatorTest`, `CheckoutTest` | ✅ Pass |
| **FR-04.2** | SĐT đúng 10 số, bắt đầu bằng 0 | **EP + BVA** | TC-UNIT-065, 066 | TC-WEB-021d/e/f/g | KTPM-131 | nt | ✅ Pass |
| **FR-04.3** | Địa chỉ 1–100 ký tự | **BVA** | TC-UNIT-067, 068 | TC-WEB-021h/i, 022 | KTPM-132 | nt | ✅ Pass |
| **FR-04.4** | Giỏ rỗng → không cho thanh toán | EP | TC-UNIT-069, 078 | TC-WEB-023 | KTPM-133 | nt | ✅ Pass |
| **FR-04.5** | Đặt hàng thành công → mã đơn + xóa giỏ | Luồng chính | TC-UNIT-075, 076, 077 | TC-WEB-020, 030, TC-PW-005, TC-MOB-003 | KTPM-134 | `CheckoutServiceTest`, `E2ETest` | ✅ Pass |
| **FR-05** | Đăng xuất về màn hình đăng nhập | Sơ đồ trạng thái S11 | — | TC-WEB-006 | KTPM-140 | `LoginTest` | ✅ Pass |
| **FR-06.1** | `Calculator` 4 phép tính + chia 0 | EP + lớp không hợp lệ | TC-UNIT-001..008 | — | KTPM-150 | `CalculatorTest` | ✅ Pass |
| **FR-06.2** | `Rational` chuẩn hóa, 4 phép toán, so sánh | **Phủ lệnh/nhánh + Cyclomatic** | TC-UNIT-010..023 | — | KTPM-151 | `RationalTest` | ✅ Pass |

**Độ phủ yêu cầu: 24/24 = 100%.**

## 2. Ma trận ngược: Test case → Yêu cầu

Kiểm tra không có test case "mồ côi" (không phục vụ yêu cầu nào):

| Nhóm test case | Số lượng | Yêu cầu phục vụ |
| --- | --- | --- |
| TC-UNIT-001..008 | 17 | FR-06.1 |
| TC-UNIT-010..023 | 36 | FR-06.2 |
| TC-UNIT-030..039 | 14 | FR-01.1 … FR-01.7 |
| TC-UNIT-040..049 | 16 | FR-02.1 … FR-02.5 |
| TC-UNIT-050..057 | 27 | FR-03.1 … FR-03.4 |
| TC-UNIT-060..070 | 30 | FR-04.1 … FR-04.4 |
| TC-UNIT-075..078 | 4 | FR-04.4, FR-04.5 |
| TC-WEB-001..006 | 11 | FR-01.*, FR-05 |
| TC-WEB-010..019 | 12 | FR-02.*, FR-03.* |
| TC-WEB-020..023 | 12 | FR-04.* |
| TC-WEB-030 | 1 | Luồng đầu-cuối (FR-01→FR-04) |
| TC-PW-001..005 | 5 | Đối chứng công cụ (không thêm độ phủ yêu cầu) |
| TC-MOB-001..003 | 3 | Kiểm chứng chạy được trên thiết bị di động |
| **Tổng** | **188 lượt chạy** (185 test case, 3 mobile tùy chọn) | — |

## 3. Ma trận: Kỹ thuật đã học → Nơi áp dụng

| Bài học | Kỹ thuật | Áp dụng tại | Bằng chứng |
| --- | --- | --- | --- |
| W5 | Bảng quyết định | FR-03 | `DiscountPolicy.java` hiện thực đúng 8 rule; TC-UNIT-050 |
| W6 | Sơ đồ chuyển trạng thái | FR-01 | Sơ đồ Mermaid + bảng 11 phép chuyển; TC-UNIT-030..039 |
| W7 | Phân hoạch tương đương | FR-04 | 12 lớp tương đương; TC-UNIT-063, 066 |
| W7 | Giá trị biên | FR-02, FR-03, FR-04 | Công thức `4n+1`; TC-UNIT-041, 051, 061 |
| W7 | Lưu đồ + Cyclomatic | FR-06.2 | V(G)=2 cho `divide`, `normalize`, `GCD`; TC-UNIT-016, 017 |
| W8 | Unit test equals/notEquals | FR-06.1 | TC-UNIT-002, 004, 018, 019 |
| W10 | Mock đối tượng phụ thuộc | FR-01 | EasyMock mock `UserRepository`; toàn bộ `LoginServiceTest` |
| W11 | Maven multi-module, TDD | Toàn dự án | 7 module Maven; quy trình đỏ→xanh quay trong video |
| W12 | Selenium WebDriver/IDE/Grid | FR-01…FR-05 | `web-selenium` (Page Object Model), `-Dgrid.url` |

## 4. Liên kết Jira ⟷ mã nguồn ⟷ báo cáo

Chuỗi liên kết đầy đủ của một test case (ví dụ TC-WEB-005):

```
Jira KTPM-105  (issue type Test, priority Highest, assignee: Thành viên A)
   │  smart commit: "KTPM-105 add lockout UI test"
   ▼
GitHub nhánh feature/KTPM-105-lockout  →  Pull Request #7  →  merge vào main
   │
   ▼
Mã nguồn: web-selenium/.../LoginTest.java#tcWeb005_lockAfterThreeFailures
   │  chú thích @Issue("KTPM-105")
   ▼
Jenkins build #12  →  Allure report: nhấn vào test case sẽ mở thẳng issue KTPM-105 trên Jira
```

Cấu hình để Allure trỏ ngược về Jira (đặt trong `allure.properties`):

```properties
allure.link.issue.pattern=https://<tên-site>.atlassian.net/browse/{}
```
